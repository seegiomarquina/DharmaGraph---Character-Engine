-- entity_counts

        SELECT node_type, COUNT(*) AS total_entities
        FROM nodes
        GROUP BY node_type
        ORDER BY total_entities DESC;
    

-- relationship_counts

        SELECT relationship, COUNT(*) AS total
        FROM relationships
        GROUP BY relationship
        ORDER BY total DESC;
    

-- most_connected_entities

        SELECT source AS entity, COUNT(*) AS connections
        FROM relationships
        GROUP BY source
        ORDER BY connections DESC
        LIMIT 10;
    

-- verse_counts

        SELECT kanda, COUNT(*) AS total_verses
        FROM verses
        GROUP BY kanda
        ORDER BY total_verses DESC;
    

